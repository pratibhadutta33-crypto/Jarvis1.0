# J.A.R.V.I.S. — Holographic Lab

A responsive, no-watermark holographic assistant interface for iPhone, Android, and laptop browsers.

## Included
- Animated atom/core, floating HUD panels, particle field and responsive layout
- Browser speech output and optional speech recognition (support varies by browser)
- Real camera-based hand gesture recognition using MediaPipe
- Optional real AI chat via a separate Node backend
- Local demo mode when the AI backend is not connected

## Important architecture
**GitHub Pages can host the static frontend, but it cannot securely run the private AI backend.** Deploy `frontend/` to GitHub Pages and deploy `backend/` to a server host that supports Node.js. Keep the AI key only in the backend host's environment variables. Do not put it in `frontend/app.js`, HTML, or a public GitHub repository.

## Part A — Upload the frontend to your existing GitHub repository
Repository: `https://github.com/apexenn012-blip/JarvissByTonoyyy`

1. Download and unzip this project.
2. Open your repository on GitHub.
3. Upload the contents of the `frontend` folder to the repository root (so `index.html`, `style.css`, and `app.js` are directly at the root).
4. Commit the changes.
5. In the repository, open **Settings → Pages**.
6. Under build/deployment, choose **Deploy from a branch**, select `main` and `/(root)`, then Save. If your default branch is not `main`, select the branch that contains your files.
7. Wait for deployment. Your site should be at:
   `https://apexenn012-blip.github.io/JarvissByTonoyyy/`

If your repo currently has an `index.html`, replace it with the one from `frontend/`. Make sure the filename is exactly `index.html` (lowercase).

## Part B — Enable real AI safely
You need a backend host that supports Node.js. Use a reputable Node hosting provider; availability and free-tier terms can change.

1. Create a separate backend project using the contents of the `backend` folder.
2. Configure the backend host to run `npm install` during build (if asked) and `npm start` to start.
3. Add environment variables in the backend host's dashboard:
   - `OPENAI_API_KEY`: your private API key
   - `OPENAI_MODEL`: `gpt-4.1-mini` (or a model available to your API account)
   - `FRONTEND_ORIGIN`: `https://apexenn012-blip.github.io`
   - `PORT`: usually supplied by the host; otherwise `3000`
4. Deploy the backend. Test its health endpoint by opening `https://YOUR-BACKEND-DOMAIN/api/health`. It should return JSON with `ok: true` and `aiConfigured: true`.
5. Open your deployed frontend in a browser. Open developer tools if available and run:
   `localStorage.setItem('jarvis_api_base','https://YOUR-BACKEND-DOMAIN')`
   Then reload the page. Replace the example domain with your real backend URL, with no trailing slash.
6. For the phone, you can set this from the browser console on a laptop first; if your phone browser doesn't share local storage, use the optional config method below.

### Optional easier config method
In `frontend/app.js`, find:
`const API_BASE = (localStorage.getItem("jarvis_api_base") || "").replace(/\/+$/, "");`
Replace it with:
`const API_BASE = "https://YOUR-BACKEND-DOMAIN";`
This backend URL is public information and is not a secret. Upload the edited `app.js` to GitHub. **Never place the API key here.**

## Part C — Enable camera gestures
1. Open the published website over HTTPS.
2. Press **ACTIVATE CAMERA** and grant camera permission.
3. Keep one hand in view, in good lighting. Try an open palm, thumbs up, victory sign, or closed fist.
4. Press **DISABLE CAMERA** to stop the camera. The site does not upload camera frames to your AI backend; gesture recognition runs in the browser. The MediaPipe library/model are downloaded from their providers when needed.

Camera access needs HTTPS or localhost and user permission. Browser and device compatibility can differ. The website needs internet to download MediaPipe assets on first use.

## Part D — Voice
- Tap the microphone button to start voice recognition where supported.
- If the browser does not support speech recognition, type into the chat box.
- Spoken replies use the browser's speech synthesis. Voice selection and quality vary by device/browser.

## Security and costs
- Never commit `.env` or an API key to GitHub. The backend `.gitignore` excludes `.env`.
- Keep the API key in the backend host's environment variables. If a key is accidentally exposed, revoke it and create a replacement.
- API usage may cost money and is separate from GitHub Pages hosting. Check the provider's current pricing and usage controls before enabling it. Set any available budget alerts/limits, and do not share the key.
- This starter includes basic input length checks and CORS, but CORS is not authentication and does not prevent all abuse. Before sharing the app publicly, add server-side rate limiting and stronger access controls.
- Do not add private keys to frontend environment variables in a static-site build: they become public in the delivered code.

## Troubleshooting
- **404:** ensure `index.html` is at the deployed root and Pages is enabled for the correct branch/folder. Wait a few minutes after saving.
- **Camera doesn't start:** check browser permissions, HTTPS, and whether another app is using the camera.
- **Gesture library fails:** check internet access and reload; CDN/model download may be blocked.
- **AI says local demo mode:** backend isn't configured or the frontend API URL hasn't been set.
- **AI request fails:** check backend logs, API account billing/access, allowed origin, and model availability.
- **Voice input unavailable:** type your message; not all browsers support the same speech recognition API.

This is a starter project, not an official Iron Man product. The interface and branding here are original and do not use a video watermark.
