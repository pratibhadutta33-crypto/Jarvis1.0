import "dotenv/config";
import express from "express";
import cors from "cors";
import OpenAI from "openai";

const app = express();
const port = Number(process.env.PORT || 3000);
const allowedOrigin = (process.env.FRONTEND_ORIGIN || "").trim();
app.disable("x-powered-by");
app.use(cors({
  origin(origin, callback) {
    // Permit non-browser health checks with no Origin; browsers must match the configured origin.
    if (!origin || !allowedOrigin || origin === allowedOrigin) return callback(null, true);
    return callback(new Error("Origin not allowed by CORS"));
  },
  methods: ["GET", "POST"],
  allowedHeaders: ["Content-Type"]
}));
app.use(express.json({ limit: "20kb" }));

const client = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, aiConfigured: Boolean(client) });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!client) return res.status(503).json({ error: "AI is not configured on the server yet." });
    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    if (!message) return res.status(400).json({ error: "Please send a message." });
    if (message.length > 2000) return res.status(413).json({ error: "Message is too long (maximum 2000 characters)." });

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      instructions: "You are JARVIS, a helpful, calm, concise personal AI assistant inside a futuristic holographic interface. Be friendly and practical. Do not claim to control device hardware or access data unless a tool actually provides it.",
      input: message,
      max_output_tokens: 500
    });
    const reply = (response.output_text || "").trim();
    res.json({ reply: reply || "I couldn't produce a response. Please try again." });
  } catch (error) {
    console.error("Chat request failed:", error?.status || error?.message || "Unknown error");
    res.status(500).json({ error: "The AI request failed. Check server logs and API account configuration." });
  }
});

app.listen(port, "0.0.0.0", () => {
  console.log(`JARVIS backend listening on port ${port}`);
});